print("Enter an integer greater than 1: ")
x = int(input())

for i in range(x+1):
    print("The cube of "+ str(i) + " is " + str(i**3))